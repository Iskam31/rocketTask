<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://digitalapps.com
 * @since      1.0.0
 *
 * @package    WP_Swiper
 * @subpackage WP_Swiper/includes
 */

class WP_Swiper_Deactivator {

    public static function deactivate() {

    }

}
